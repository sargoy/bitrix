<?php

class GetExchangeRatesExt
{
    private $date;
    private $url;
    private $html;
    private $dom;
    private $tables;
    private $rows;
    private $curs = [];

    public function getJSON(): string
    {
        $this->date = date('d.m.Y');

        $this->url = "http://www.cbr.ru/currency_base/D_print.aspx?date_req=$this->date";  //URL страницы с курсами валют на сегодня

        $this->html = file_get_contents($this->url); //содержимое HTML страницы
    
        $this->dom = new domDocument; // создаем объект дерева DOM
    
        $this->dom->loadHTML($this->html);
        $this->dom->preserveWhiteSpace = false;
    
        $this->tables = $this->dom->getElementsByTagName('table'); // получаем из дерева DOM первую таблицу, ею является как раз таблица содержащая курсы валют
        $this->rows = $this->tables->item(0)->getElementsByTagName('tr');
        
        foreach ($this->rows as $key => $row) {
            
            if ($key) {
            
                $cols = $row->getElementsByTagName('td');
                
                $this->curs[$key][0] = $cols->item(0)->nodeValue; // Цифр. код
                $this->curs[$key][1] = $cols->item(1)->nodeValue; // Букв. код 
                $this->curs[$key][2] = $cols->item(2)->nodeValue; // Единиц
                $this->curs[$key][3] = $cols->item(3)->nodeValue; // Валюта
                $this->curs[$key][4] = $cols->item(4)->nodeValue; // Курс
    
            }
        }
        return json_encode($this->curs);
    }
}