<?php

require_once 'conn.php';
class Insert
{
    private $database;
    private $db;
    private $stm;

    function ins(): object
    {
        try
        {
            $this->database = new Connection();
            $this->db = $this->database->openConnection();
            // inserting data into create table using prepare statement to prevent from sql injections
            $this->stm = $this->db->prepare("INSERT INTO courses (code,sname,eval,rus,curs) VALUES ( :code, :sname, :eval, :rus, :curs)") ;

            return $this->stm;
        }
        catch (PDOException $e)
        {
            echo "There is some problem in connection: " . $e->getMessage();
        }
    }
}