<?php

require_once 'conn.php';

class Select
{
    private $database;
    private $db;
    private $sql;
    private $arr = [];

    function request(): array
    {
        try
        {
            $this->database = new Connection();
            $this->db = $this->database->openConnection();
            $this->sql = "SELECT * FROM courses";

            foreach ($this->db->query($this->sql) as $row) {

                $this->arr[] = $row;
            }
            return $this->arr;
        }
        catch (PDOException $e)
        {
            echo "There is some problem in connection: " . $e->getMessage();
        }
    }
}

