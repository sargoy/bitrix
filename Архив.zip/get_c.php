<?php

//здесь можно было использовать автозагрузку
require_once 'cours.php';
require_once 'select.php';
require_once 'insert.php';

class Controller
{

    private $filename = 'course.json';
    private $ob_json;
    private $ob_ins;
    private $ob_db;
    private $content;
    
    public function getCourses(): array
    {
        if (!file_exists($this->filename) || date('d.m.Y', filemtime($this->filename)) != date('d.m.Y')) {

            //вызываем класс с запрсом к БД, хотя это действие выглядит избыточным, т.к. без внешнего источника не обойтись, а формирование массива все равно происходит из кэша.
            $this->ob_db = new Select();

            if ($this->ob_db->request()) {

                file_put_contents($this->filename, json_encode($this->ob_db->request()));

            } else {
                //вызываем класс с запрсом к внешнему источнику
                $this->ob_json = new GetExchangeRatesExt();
        
                //формируем файл с данными
                file_put_contents($this->filename, $this->ob_json->getJSON());

                //вызываем класс добавления записи в БД
                $this->ob_ins = new Insert();
                $this->content = json_decode($this->ob_json->getJSON(), true);
                $this->ob_ins->ins()->execute($this->content);
            }
        }

        if (file_exists($this->filename) && date('d.m.Y', filemtime($this->filename)) == date('d.m.Y')) {

            $this->content = file_get_contents($this->filename);

            return json_decode($this->content, true);
        }
    }

}